export interface IAddItemRequestData {
    tid: string;
    items: any[];
}
