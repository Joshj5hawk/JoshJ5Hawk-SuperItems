export interface IRemoveOfferRequestData {
    Action: string;
    offerId: string;
}
