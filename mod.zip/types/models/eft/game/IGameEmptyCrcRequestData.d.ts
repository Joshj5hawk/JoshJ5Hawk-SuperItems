export interface IGameEmptyCrcRequestData {
    crc: number;
}
