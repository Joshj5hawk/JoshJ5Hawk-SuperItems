export interface IFriendRequestData {
    to: string;
}
