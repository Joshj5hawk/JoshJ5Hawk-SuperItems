export declare enum RaidMode {
    Online = "Online",
    Local = "Local",
    Coop = "Coop"
}
