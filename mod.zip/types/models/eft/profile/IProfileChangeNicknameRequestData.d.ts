export interface IProfileChangeNicknameRequestData {
    nickname: string;
}
