export interface IPutMetricsRequestData {
    sid: string;
    settings: any;
    SharedSettings: any;
    HardwareDescription: any;
    Location: string;
    Metrics: any;
    ClientEvents: any;
    SpikeSamples: any[];
}
