export interface ILoginRequestData {
    username: string;
    password: string;
}
