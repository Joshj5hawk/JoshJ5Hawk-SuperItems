export interface IBaseConfig {
    kind: string;
}
