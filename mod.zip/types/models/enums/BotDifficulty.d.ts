export declare enum BotDifficulty {
    AsOnline = "AsOnline",
    Easy = "Easy",
    Medium = "Medium",
    Hard = "Hard",
    Impossible = "Impossible",
    Random = "Random"
}
