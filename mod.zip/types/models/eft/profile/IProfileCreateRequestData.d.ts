export interface IProfileCreateRequestData {
    side: string;
    nickname: string;
    headId: string;
    voiceId: string;
}
